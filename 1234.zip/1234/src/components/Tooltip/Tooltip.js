import styles from 'Tooltip.module.css';

const Tooltip = () => {
  return (
    <div className={styles.tooltip} style={{ left: '50%', top: '50%' }}>
      <div className={styles.pulseButton}></div>
      <div className={styles.tooltipContent}>
        <a
          className={styles.name}
          href={tooltipItem.productLink}
          target='_blank'
          rel='noopener noreferrer'>
          {tooltipItem.name}
        </a>
        <div className={styles.brand}>{tooltipItem.brand}</div>
      </div>
    </div>
  );
};

export default Tooltip;

// {item.tooltips.map((tooltipItem) => {
//   return (
//     <div
//       className={styles.tooltip}
//       style={{
//         left: tooltipItem.position.left,
//         top: tooltipItem.position.top,
//       }}
//       key={tooltipItem.id}>
//       <div className={styles.pulseButton}></div>
//       <div className={styles.tooltipContent}>
//         <a
//           className={styles.name}
//           href={tooltipItem.productLink}
//           target='_blank'
//           rel='noopener noreferrer'>
//           {tooltipItem.name}
//         </a>
//         <div className={styles.brand}>{tooltipItem.brand}</div>
//       </div>
//     </div>
//   );
// })}
