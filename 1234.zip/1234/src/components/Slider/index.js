export { default } from './Slider';
